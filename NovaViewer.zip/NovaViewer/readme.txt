
Description
===========

NovaViewer is a tool for Windows operating system that collects
information from various sources on a running system, and displays a log
of actions made by the user and events occurred on this computer. The
activity displayed by NovaViewer includes: Running .exe file,
Opening open/save dialog-box, Opening file/folder from Explorer or other
software, software installation, system shutdown/start, application or
system crash, network connection/disconnection and more...

You can easily export this information into csv/tab-delimited/xml/html
file or copy it to the clipboard and then paste into Excel or other
software.



System Requirements
===================

This utility works on any version of Windows, starting from Windows 2000
and up to Windows 11. Both 32-bit and 64-bit systems are supported.






* Version 1.02:
  o User information is now displayed for 'User Logoff' event.
  o Fixed the flickering occurred while scrolling the actions/events
    list.

* Version 1.01:
  o Added 'Mark Odd/Even Rows' option, under the View menu. When it's
    turned on, the odd and even rows are displayed in different color, to
    make it easier to read a single line.

* Version 1.00 - First release.



Start Using NovaViewer
============================

NovaViewer doesn't require any installation process or additional
dll files. In order to start using it, simply run the executable file -
NovaViewer.exe

After you run NovaViewer, it scans your computer and displays all
actions and events found on your system.
You can select one or more items and then save them into
xml/html/csv/tab-delimited file (Ctrl+S) or copy them to the clipboard
(Ctrl+C), and then paste the data to Excel or other software.







How to delete the information displayed by NovaViewer...
==============================================================

Since the release of NovaViewer utility, many people contact me
with the same question: How do I delete the information displayed by
NovaViewer ?

Unfortunately, there is no simple answer to this question because the
information is collected from multiple sources, and currently
NovaViewer doesn't provide an option to automatically delete this
information.
Also, some of the data collected by NovaViewer is essential to
normal functioning of Windows operating system and deleting it may cause
some problems.

In the following section, you can find the list of all sources that
NovaViewer uses to collect the activity information and how to
optionally delete them.
Be aware that deleting any data from your computer is on your own risk,
and I cannot give any kind of support for people who want to recover data
they deleted from their computer according to this article.


* Events log of Windows operating system: The following events are
  taken from the Events log of Windows: User Logon, User Logoff, Windows
  Installer Started, Windows Installer Ended, System Started, System
  Shutdown, Resumed from sleep, Restore Point Created, Network Connected,
  Network Disconnected, Software Crash, Software stopped responding (hang)
  Windows operating system doesn't allow you to delete individual items
  from the events log, but you can easily clear the entire events log. In
  order to to clear the entire events log, simply go to Control Panel ->
  Administrative Tools -> Event Viewer , and then choose to clear (Action
  -> Clear All Events) all major types of events logs (Application,
  Security, System...)


* Windows Prefetch Folder: The Prefetch folder of Windows is usually
  located under C:\windows\Prefetch and it's used by windows to optimize
  the performances of running applications. Every time that you run an
  executable (.exe) file, .pf file is generated under this folder.
  NovaViewer uses this folder for 'Run .EXE file' event.
  In order to delete all 'Run .EXE file' events shown by
  NovaViewer, simply delete all .pf files under the Prefetch folder.


* Open/Save MRU list in the Registry: Every time that you choose a
  filename in a standard open/save dialog-box of Windows, a new Registry
  entry is added under the following key:
  On Windows XP and previous systems:
  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\ComD
  lg32\OpenSaveMRU
  On Windows 7/8/2008:
  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\ComD
  lg32\OpenSavePidlMRU

  NovaViewer uses the above Registry keys for the 'Select file in
  open/save dialog-box' event.

  If you delete the entries under the above Registry keys (with RegEdit),
  Windows will not rememeber your last saved file/folder.


* Recent Folder: Every time that you open a file, a new shortcut to
  this file is added to the recent folder of Windows, located under
  C:\Documents and Settings\[User Profile]\Recent or C:\Users\[User
  Profile]\Recent
  NovaViewer uses the recent folder of Windows to add the 'Open
  file or folder' event. You can delete this type of event simply by
  deleting all shortcuts under the recent folder of Windows.


* Windows Shell Bags Regsitry key: Windows Explorer remembers the
  settings (position, Size, columns position, and so on) or every folder
  you open by storing it under the following Registry keys:
  HKEY_CURRENT_USER\Software\Microsoft\Windows\ShellNoRoam
  HKEY_CURRENT_USER\Software\Microsoft\Windows\Shell
  HKEY_CURRENT_USER\Software\Classes\Local
  Settings\Software\Microsoft\Windows\Shell

  NovaViewer uses the above Registry keys to add the 'View Folder
  in Explorer' event. If you delete the subkeys under the above Registry
  keys (With RegEdit), Windows will "forget" the settings of all folders.


* Software Uninstall Registry Key: The 'Software Installation' event is
  taken from the following Registry keys:
  HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall
  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall

  Warning !!!!
  If you delete any Entry from these Registry keys, you'll not be able to
  uninstall the software in the future !





Command-Line Options
====================



/stext <Filename>
Save the actions and events list into a regular text file.

/stab <Filename>
Save the actions and events list into a tab-delimited text file.

/scomma <Filename>
Save the actions and events list into a comma-delimited text file (csv).

/stabular <Filename>
Save the actions and events list into a tabular text file.

/shtml <Filename>
Save the actions and events list into HTML file (Horizontal).

/sverhtml <Filename>
Save the actions and events list into HTML file (Vertical).

/sxml <Filename>
Save the actions and events list into XML file.



